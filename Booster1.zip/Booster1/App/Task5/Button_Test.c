/*
 * Button_Test.c
 *
 *  Created on: Apr 27, 2020
 *      Author: Lobna Gamal



#include "../../Infrastructure/Macros.h"
#include "../../Infrastructure/Interrupts.h"

#include "../../MCAL/DIO/dio.h"
#include "../../ECUAL/BUTTON/button.h"




void button_test(void)
{
	Button_Init(Button_Pin_1);
	Dio_SetPinDirection(DIO_PORTD,7,OUTPUT);



	while(1)
	{
		if(Button_Status(Button_Pin_1)==1)
		{
			Dio_SetPinValue(DIO_PORTD,7,HIGH);

		}
		else if(Button_Status(Button_Pin_2)==1)
		{
			Dio_SetPinValue(DIO_PORTD,7,LOW);
		}
	}

}


*/
