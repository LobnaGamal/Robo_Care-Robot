/*
 * DIO_Test.c
 *
 *  Created on: Apr 27, 2020
 *      Author: Lobna Gamal
 */
#include "../../MCAL/DIO/dio.h"

void DIO_Test(void)
{
	Dio_SetPinDirection(DIO_PORTD,PIN7,OUTPUT);
	Dio_SetPinValue(DIO_PORTD,PIN7,HIGH);
}
