/*
 * PWM_Test.c
 *
 *  Created on: Apr 27, 2020
 *      Author: Lobna Gamal

#include "../../Infrastructure/Macros.h"
#include "../../Infrastructure/Interrupts.h"

#include "../../MCAL/DIO/dio.h"

#include"../../MCAL/TIMER0/timer.h"
#include "../../ECUAL/SW_PWM/PWM.h"



//str_PWM_config_t gstr_Pwm_Config={PWM_CH7 , DUTY_CYCLE_CONFIG};



//extern uint8_t gu8_Duty_cycle;


void pwm_test(void)
{
	GI_EN();

	Dio_SetPinDirection(DIO_PORTD,PIN7,OUTPUT);
	Dio_SetPinDirection(DIO_PORTD,PIN6,OUTPUT);
	Dio_SetPinDirection(DIO_PORTD,PIN5,OUTPUT);

	PWM_init(&gstr_Pwm_Config);


	while(1)
	{
		//PWM_update(gu8_Duty_cycle);
	;	//Dio_SetPinValue(DIO_PORTD,PIN6,HIGH);

	}
}
/*
void ISR(TIMER0_COMP)
{
	Dio_SetPinValue(PWM_PORT, PWM_CH7, LOW);
	Dio_SetPinValue(PWM_PORT, PWM_CH6, HIGH);
}

*/

/*
void ISR(TIMER0_COMP)
{
	static uint8_t u8_count=0;
	if(u8_count==0)
	{
		//Dio_SetPinValue(DIO_PORTD,PIN6,HIGH);
		Dio_SetPinValue(DIO_PORTD,PIN5,HIGH);
		Dio_SetPinValue (MY_PORT,MY_PIN, LOW);
		gu8_Duty_cycle=100-gu8_Duty_cycle;
		u8_count++;
	}
	else if(u8_count==1)
	{
		Dio_SetPinValue(DIO_PORTD,PIN6,HIGH);

		Dio_SetPinValue (MY_PORT,MY_PIN, HIGH);
		gu8_Duty_cycle=100-gu8_Duty_cycle;
		u8_count--;
	}

}

*/
