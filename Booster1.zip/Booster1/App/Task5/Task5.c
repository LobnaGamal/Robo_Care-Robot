/*
 * Task5.c
 *
 *  Created on: Apr 27, 2020
 *      Author: Lobna Gamal
*/


#include "../../Infrastructure/Macros.h"
#include "../../Infrastructure/Interrupts.h"

#include "../../ECUAL/SW_PWM/PWM.h"
#include "../../ECUAL/BUTTON/button.h"


str_PWM_config_t gstr_Pwm_Config={PWM_CH7 , DUTY_CYCLE_CONFIG};



void Task_Test(void)
{
	Button_Init(Button_Pin_1);
	Button_Init(Button_Pin_2);
	PWM_init(&gstr_Pwm_Config);

	//uint8_t status_of_button1;
	//uint8_t status_of_button2;
	uint8_t DutyCycle =  gstr_Pwm_Config.u8_duty_cycle;



	while(1)
	{
		//status_of_button1=Button_Status(Button_Pin_1);
		//status_of_button2=Button_Status(Button_Pin_2);

		if(Button_Status(Button_Pin_1)==1)
		{
			DutyCycle += 30;
			if(DutyCycle<=100)
			{
				PWM_update(PWM_CH7,DutyCycle);
			}
			else
			{
				DutyCycle-=30;
			}
		}

		if(Button_Status(Button_Pin_2)==1)
		{
			DutyCycle -= 30;
			if(DutyCycle>=0)
			{
				PWM_update(PWM_CH7,DutyCycle);
			}
			else
			{
				DutyCycle+=30;
			}
		}


	}

}





