/*
 * Timer_Test.c
 *
 *  Created on: Apr 27, 2020
 *      Author: Lobna Gamal
 */

/*
#include "../../MCAL/DIO/dio_config.h"
#include "../../MCAL/DIO/dio.h"

//#include"../../MCAL/TIMER0/timer.h"
#include "../../Infrastructure/Macros.h"
#include "../../Infrastructure/Interrupts.h"

//ST_TIMER_config_t timer_config={Compare_match,Pre_1024};
//#define tick           250





void timer_test()
{
	//uint8_t count=0;

	GI_EN();

	Dio_SetPinDirection(DIO_PORTD,PIN7,OUTPUT);
	Dio_SetPinDirection(DIO_PORTD,PIN6,OUTPUT);
	//Dio_SetPinValue(DIO_PORTD,PIN7,HIGH);

	TIMER_init(&timer_config);
	TIMER_enInterrupt(&timer_config);
	//TIMER__start(250,&timer_config);


	while(1)
	{
		while(!status());

		SET_BIT(TIFR,1);
		//Dio_SetPinValue(DIO_PORTD,PIN7,LOW);

		count++;
		if(count%4==0)
		{
			TOGGLE_BIT(PD_DATA,7);
			//
			//Dio_SetPinValue(DIO_PORTD,PIN7,LOW);

		}

	}

}


void ISR(TIMER0_COMP)
{
	 static uint8_t count=0;
	Dio_SetPinValue(DIO_PORTD,PIN6,HIGH);
	count++;
			if(count%4==0)
			{
				Dio_SetPinValue(DIO_PORTD,PIN6,LOW);
				//TOGGLE_BIT(PD_DATA,7);
				//
				//Dio_SetPinValue(DIO_PORTD,PIN7,LOW);

			}

}

*/
