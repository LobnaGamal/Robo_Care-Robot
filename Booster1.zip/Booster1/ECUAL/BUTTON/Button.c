/*
 * Button.c
 *
 *  Created on: Apr 26, 2020
 *      Author: lgamal
 */

#include "Button.h"


void Button_Init(uint8_t Button_No)
{
	Dio_SetPinDirection(Button_PORT_No,Button_No,INPUT);
}
uint8_t Button_Status(uint8_t Button_No)
{
	if(Dio_uint8GetPinValue(Button_PORT_No,Button_No)==1)
	{
		for(double i=0;i<1000;i++);
	  return 1;
	}
	else{
			return 0;

	}

}
