/*
 * Button.h
 *
 *  Created on: Apr 26, 2020
 *      Author: lgamal
 */

#ifndef BUTTON_H_
#define BUTTON_H_

#include "../../Infrastructure/Macros.h"
#include "../../Infrastructure/types.h"
#include "../../MCAL/DIO/dio.h"


#define  Button_PORT_No      DIO_PORTB

#define Button_Pin_1 0
#define Button_Pin_2 1

void Button_Init(uint8_t Button_No);
uint8_t Button_Status(uint8_t Button_No);

#endif /* BUTTON_H_ */
