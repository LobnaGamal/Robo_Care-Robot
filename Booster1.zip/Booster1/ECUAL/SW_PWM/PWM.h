/*
 * PWM.h
 *
 *  Created on: Apr 25, 2020
 *      Author: Lobna Gamal
 */

#ifndef ECAL_SW_PWM_PWM_H_
#define ECAL_SW_PWM_PWM_H_

/*-INCLUDES
----------------------------------------------------------------------------------------------------------------*/
#include"../../Infrastructure/types.h"
#include "PWM_Types.h"


/*
 * -LOCAL MACROS
----------------------------------------------------------------------------------------------------------------*/
#define MAX_STEPS             255
#define MAX_DUTY_CYCLE        100
#define MIN_DUTY_CYCLE         0



/*-FUNCTION DECLARATION
----------------------------------------------------------------------------------------------------------------*/
void PWM_init(str_PWM_config_t *configration);
void PWM_start(uint8_t channel,uint8_t u8_duty_cycle);
void PWM_stop(uint8_t channel);
void PWM_update(uint8_t channel,uint8_t u8_duty_cycle);

#endif /* ECAL_SW_PWM_PWM_H_ */
