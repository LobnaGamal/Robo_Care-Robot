/*
 * PWM_Types.h
 *
 *  Created on: Apr 25, 2020
 *      Author: Lobna Gamal
 */

#ifndef ECAL_SW_PWM_PWM_TYPES_H_
#define ECAL_SW_PWM_PWM_TYPES_H_


#define DUTY_CYCLE_CONFIG      80

#define PWM_PORT           DIO_PORTD

#define PWM_CH0            PIN0
#define	PWM_CH1            PIN1
#define	PWM_CH2            PIN2
#define PWM_CH3            PIN3
#define	PWM_CH4            PIN4
#define	PWM_CH5            PIN5
#define	PWM_CH6            PIN6
#define	PWM_CH7            PIN7





typedef struct
{
	uint8_t channel;
	uint8_t u8_duty_cycle;
}str_PWM_config_t;






#endif /* ECAL_SW_PWM_PWM_TYPES_H_ */
