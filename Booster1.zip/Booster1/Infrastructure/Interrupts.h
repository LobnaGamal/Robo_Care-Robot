/*
 * Interrupts.h
 *
 *  Created on: Apr 28, 2020
 *      Author: Lobna Gamal
 */

#ifndef INFRASTRUCTURE_INTERRUPTS_H_
#define INFRASTRUCTURE_INTERRUPTS_H_

#include "types.h"
#include "Macros.h"


#define EXTI_INT0				   	__vector_1
#define EXTI_INT1				   	__vector_2
#define EXTI_INT2				   	__vector_3
#define TIMER2_COMP					__vector_4
#define TIMER2_OVF					__vector_5
#define TIMER0_COMP					__vector_10
#define TIMER0_OVF					__vector_11
#define TIMER1_CAPT					__vector_6
#define TIMER1_COMPA				__vector_7
#define TIMER1_COMPB				__vector_8
#define TIMER1_OVF					__vector_9


#define ISR(vector)				   	vector(void) __attribute__((signal,used));\
									void vector(void)

/*
#  define __INTR_ATTRS used

#  define ISR(vector, ...)            \
    void vector (void) __attribute__ ((signal,__INTR_ATTRS)) ; \
    void vector (void)

*/


#define SREG			(*((volatile uint8_t*)(0X5F)))

#define GI_EN()			SET_BIT(SREG,7)
#define GI_DI()			CLEAR_BIT(SREG,7)


#endif /* INFRASTRUCTURE_INTERRUPTS_H_ */
