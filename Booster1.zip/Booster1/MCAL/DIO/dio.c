/*
 * dio.c
 *
 * Created: 25/04/2020 04:47:58 PM
 *  Author: Lobna Gamal
 */ 

#include "dio.h"


void Dio_SetPinValue(uint8_t uint8PortNumber,uint8_t uint8PinNumber,uint8_t uint8Value)
{
	switch(uint8PortNumber)
	{
		case DIO_PORTA :
		switch(uint8Value)
		{
			case LOW:
			CLEAR_BIT(PA_DATA,uint8PinNumber);
			break;
			case HIGH:
			SET_BIT(PA_DATA,uint8PinNumber);
			break;
		}
		break;
		
		case DIO_PORTB :
		switch(uint8Value)
		{
			case LOW:
			CLEAR_BIT(PB_DATA,uint8PinNumber);
			break;
			case HIGH:
			SET_BIT(PB_DATA,uint8PinNumber);
			break;
		}
		break;
		
		case DIO_PORTC :
		switch(uint8Value)
		{
			case LOW:
			CLEAR_BIT(PC_DATA,uint8PinNumber);
			break;
			case HIGH:
			SET_BIT(PC_DATA,uint8PinNumber);
			break;
		}
		break;
		
		case DIO_PORTD :
		switch(uint8Value)
		{
			case LOW:
			CLEAR_BIT(PD_DATA,uint8PinNumber);
			break;
			case HIGH:
			SET_BIT(PD_DATA,uint8PinNumber);
			break;
		}
		break;
	}
}


uint8_t Dio_uint8GetPinValue(uint8_t uint8PortNumber,uint8_t uint8PinNumber)
{
	switch(uint8PortNumber)
	{
		case DIO_PORTA:
		return GET_BIT(PA_STAT,uint8PinNumber);
		break;
		
		case DIO_PORTB:
		return GET_BIT(PB_STAT,uint8PinNumber);
		break;
		
		case DIO_PORTC:
		return GET_BIT(PC_STAT,uint8PinNumber);
		break;
		
		case DIO_PORTD:
		return GET_BIT(PD_STAT,uint8PinNumber);
		break;
		default:return 0;
	}
}


void Dio_SetPinDirection(uint8_t uint8PortNumber,uint8_t uint8PinNumber,uint8_t uint8Direction)
{
	switch(uint8PortNumber)
	{
		case DIO_PORTA :
		switch(uint8Direction)
		{
			case INPUT :
			CLEAR_BIT(PA_CTRL,uint8PinNumber);
			break;
			case OUTPUT:
			SET_BIT(PA_CTRL,uint8PinNumber);
			break;
		}
		break;
		
		case DIO_PORTB :
		switch(uint8Direction)
		{
			case INPUT:
			CLEAR_BIT(PB_CTRL,uint8PinNumber);
			break;
			case OUTPUT:
			SET_BIT(PB_CTRL,uint8PinNumber);
			break;
		}
		break;
		
		case DIO_PORTC :
		switch(uint8Direction)
		{
			case INPUT:
			CLEAR_BIT(PC_CTRL,uint8PinNumber);
			break;
			case OUTPUT:
			SET_BIT(PC_CTRL,uint8PinNumber);
			break;
		}
		break;
		
		case DIO_PORTD :
		switch(uint8Direction)
		{
			case INPUT:
			CLEAR_BIT(PD_CTRL,uint8PinNumber);
			break;
			case OUTPUT:
			SET_BIT(PD_CTRL,uint8PinNumber);
			break;
		}
		break;
	}
}


void Dio_SetPortValue(uint8_t uint8PortNumber,uint8_t uint8Value)
{
	switch(uint8PortNumber)
	{
		case DIO_PORTA:
		PA_DATA=uint8Value;
		break;
		
		case DIO_PORTB:
		PB_DATA=uint8Value;
		break;
		
		case DIO_PORTC:
		PC_DATA=uint8Value;
		break;
		
		case DIO_PORTD:
		PD_DATA=uint8Value;
		break;
	}
}


uint8_t Dio_uint8GetPortValue(uint8_t uint8PortNumber)
{
	switch(uint8PortNumber)
	{
		case DIO_PORTA:
		return PA_STAT;
		break;
		
		case DIO_PORTB:
		return PB_STAT;
		break;
		
		case DIO_PORTC:
		return PC_STAT;
		break;
		
		case DIO_PORTD:
		return PD_STAT;
		break;

		default:return 0;
	}
}


void Dio_SetPortDirection(uint8_t uint8PortNumber,uint8_t uint8Direction)
{
	switch(uint8PortNumber)
	{
		case DIO_PORTA:
		PA_CTRL=uint8Direction;
		break;
		
		case DIO_PORTB:
		PB_CTRL=uint8Direction;
		break;
		
		case DIO_PORTC:
		PC_CTRL=uint8Direction;
		break;
		
		case DIO_PORTD:
		PD_CTRL=uint8Direction;
		break;
	}
}

