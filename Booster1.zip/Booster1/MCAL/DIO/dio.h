/*
 * dio.h
 *
 * Created: 25/04/2020 03:19:37 PM
 *  Author: Lobna Gamal
 */ 



#ifndef DIO_H_
#define DIO_H_

#include "../../Infrastructure/Macros.h"
#include "./dio_config.h"


void Dio_SetPinValue(uint8_t uint8PortNumber,uint8_t uint8PinNumber,uint8_t uint8Value);
uint8_t Dio_uint8GetPinValue(uint8_t uint8PortNumber,uint8_t uint8PinNumber);
void Dio_SetPinDirection(uint8_t uint8PortNumber,uint8_t uint8PinNumber,uint8_t uint8Direction);

void Dio_SetPortValue(uint8_t uint8PortNumber,uint8_t uint8Value);
uint8_t Dio_uint8GetPortValue(uint8_t uint8PortNumber);
void Dio_SetPortDirection(uint8_t uint8PortNumber,uint8_t uint8Direction);


#define DIO_PORTA  0
#define DIO_PORTB  1
#define DIO_PORTC  2
#define DIO_PORTD  3

#define PIN0 0
#define PIN1 1
#define PIN2 2
#define PIN3 3
#define PIN4 4
#define PIN5 5
#define PIN6 6
#define PIN7 7

#define HIGH 1
#define LOW 0

#define OUTPUT 1
#define INPUT 0


#endif /* DIO_H_ */
