/*
 * dio_config.h
 *
 * Created: 25/04/2020 04:56:41 PM
 *  Author: Lobna Gamal
 */ 


#ifndef DIO_CONFIG_H_
#define DIO_CONFIG_H_

#include "../../Infrastructure/types.h"

#define PA_DATA (*((volatile uint8_t*)0x3B))        //PORTA
#define PA_CTRL (*((volatile uint8_t*)0x3A))        //DDRA
#define PA_STAT (*((volatile uint8_t*)0x39))        //PINA

#define PB_DATA (*((volatile uint8_t*)0x38))        //PORTB
#define PB_CTRL (*((volatile uint8_t*)0x37))        //DDRB
#define PB_STAT (*((volatile uint8_t*)0x36))        //PINB

#define PC_DATA (*((volatile uint8_t*)0x35))        //PORTC
#define PC_CTRL (*((volatile uint8_t*)0x34))        //DDRC
#define PC_STAT (*((volatile uint8_t*)0x33))        //PINC

#define PD_DATA (*((volatile uint8_t*)0x32))        //PORTD
#define PD_CTRL (*((volatile uint8_t*)0x31))        //DDRD
#define PD_STAT (*((volatile uint8_t*)0x30))        //PIND



#endif /* DIO_CONFIG_H_ */
