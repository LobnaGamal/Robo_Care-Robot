/*
 * timer.c
 *
 * Created: 4/26/2020 2:23:05 PM
 *  Author: Lobna Gamal
 */ 

/*-INCLUDES
----------------------------------------------------------------------------------------------------------------*/

#include "timer.h"




//#define tick           50

/*
 * -GLOBAL EXTERN VARIABLES
----------------------------------------------------------------------------------------------------------------*/
ST_TIMER_config_t timer_config={Compare_match,Pre_1024};




/*
 *  -APIs IMPLEMENTATION
----------------------------------------------------------------------------------------------------------------*/
void TIMER_init(ST_TIMER_config_t *configuration)
{

	switch (configuration->modes){

	case Normal_mode   : Normal_MODE_TIMER();
	break;
	case Compare_match : Comper_MATCH_TIMER();	
	break;
	}


	//TIMER_enInterrupt(&timer_config);

		//TIMER_start(tick);

	switch (configuration->prescaler)
	{ 
	case Pre_1      : TCCR0 |=(CS00);
	break;
	case Pre_8      : TCCR0 |=(CS01);
	break;
	case Pre_64     : TCCR0 |=(CS01)|(CS00);
	break;
	case Pre_256    : TCCR0 |=(CS02);
	break;
	case Pre_1024   : TCCR0 |=(CS02)|(CS00);
	break;
	case fallingEdge: TCCR0 |=(CS01)|(CS02);
	break;
	case risingEdge : TCCR0 |=(CS01)|(CS02)|(CS00);
	break;

	}

}


void Normal_MODE_TIMER()
{
	TCNT0 = 0;             //timer initial value
	//TIMSK |= (TOIE0);  //enable overflow interrupt
	TCCR0 |= FOC0 ;  //Not PWM                                  //warning here ??
}
void Comper_MATCH_TIMER()
{
	TCNT0 = 0;                        //timer initial value
	//TIMSK|= (OCIE0);               //enable compare interrupt
	TCCR0 |= FOC0 | WGM01 ;                                  //warning here ??
	/* Configure timer0 control register
	 * 1. Non PWM mode FOC0=1
	 * 2. CTC Mode WGM01=1 & WGM00=0
	 */
}



void TIMER__read(uint8_t *value)
{
	*value =(uint8_t)TCNT0;
}

void TIMER__set(uint8_t value)
{
	TCNT0 =value;
}




// function timer_start (tick)

void TIMER_start(uint8_t Tick,ST_TIMER_config_t *configuration)
{
	if(configuration->modes==Normal_mode)
	{

		TCNT0=255-Tick;
	}
	else if(configuration->modes==Compare_match)
	{
		OCR0=Tick;
		TCNT0=0;
	}
}



void TIMER_enInterrupt(ST_TIMER_config_t *configuration)
{
	if(configuration->modes==Normal_mode)
	{
		SET_BIT(TIMSK,0);
	}
	else if(configuration->modes==Compare_match)
	{
		SET_BIT(TIMSK,1);
	}
}


void TIMER_diInterrupt(ST_TIMER_config_t *configuration)
{
	if(configuration->modes==Normal_mode)
	{
		CLEAR_BIT(TIMSK,0);
	}
	else if(configuration->modes==Compare_match)
	{
		CLEAR_BIT(TIMSK,1);
	}

}

uint8_t status()
{
	if(GET_BIT(TIFR,1)==1)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}


