/*
 * timer.h
 *
 *  Created on: Apr 28, 2020
 *      Author: Lobna Gamal
 */

#ifndef MCAL_TIMER0_TIMER_H_
#define MCAL_TIMER0_TIMER_H_

#include "timer_types.h"
#include "../../Infrastructure/types.h"


//ST_TIMER_config_t timer_config={Compare_match,Pre_1024};




/*-FUNCTION DECLARATION
----------------------------------------------------------------------------------------------------------------*/
void TIMER_init(ST_TIMER_config_t *configuration);
void TIMER_start(uint8_t Tick,ST_TIMER_config_t* configuration);

void TIMER__read(uint8_t *value);

void TIMER__set(uint8_t value);

void Normal_MODE_TIMER();
void Comper_MATCH_TIMER();
void TIMER_enInterrupt(ST_TIMER_config_t *configuration);
void TIMER_diInterrupt(ST_TIMER_config_t *configuration);

uint8_t status();

#endif /* MCAL_TIMER0_TIMER_H_ */
