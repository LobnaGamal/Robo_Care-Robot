/*r
 * IncFile1.h
 *
 * Created: 4/26/2020 4:25:22 PM
 *  Author: Lobna Gamal
 */ 


#ifndef TIMER_HW_H_
#define TIMER_HW_H_

#include "../../Infrastructure/types.h"
#include "../../Infrastructure/Macros.h"

///////////////////////////Timer Registers Address
//#define  SREG              (*((volatile uint8_t*) (0X5F)))
#define  OCR0              (*((volatile uint8_t*) (0X5C)))
#define  TCCR0             (*((volatile uint8_t*) (0X53)))
#define  TCNT0             (*((volatile uint8_t*) (0X52)))
#define  TIFR              (*((volatile uint8_t*) (0X58)))
#define  TIMSK             (*((volatile uint8_t*) (0X59)))
#define  GIFR              (*((volatile uint8_t*) (0X5A)))
#define  GICR              (*((volatile uint8_t*) (0X5B)))


/*-MACROS
----------------------------------------------------------------------------------------------------------------*/
///////////////////////////////pins of TCCR0
#define FOC0               0b10000000
#define WGM00              0b01000000
#define COM01              0b00100000
#define COM00              0b00010000
#define WGM01              0b00001000
#define CS02               0b00000100
#define CS01               0b00000010
#define CS00               0b00000001
/////////////////////////////////pins of TIMSK

#define OCIE0              0b00000010
#define TOIE0              0b00000001
///////////////////////////////////pins of TIFR
#define OCF0               0b00000010
#define TOV0               0b00000001



#endif /* TIMER_HW_H_ */
