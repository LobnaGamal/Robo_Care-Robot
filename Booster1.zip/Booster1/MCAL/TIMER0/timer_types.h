/*
 * timer_types.h
 *
 *  Created on: Apr 26, 2020
 *      Author: Lobna Gamal
 */

#ifndef TIMER_TYPES_H_
#define TIMER_TYPES_H_


#include "timer_hw.h"
/*-ENUMS
-------------------------------------------------------------------------------------------------------------*/

typedef enum TIMER_MODES_t {Normal_mode,Compare_match}
	         TIMER_MODES_t;

typedef enum TIMER_PRESCALER_t {Pre_1,Pre_8,Pre_64,Pre_256,Pre_1024,fallingEdge,risingEdge}
	         TIMER_PRESCALER_t;



 /*-STRUCT
-------------------------------------------------------------------------------------------------------------*/
typedef struct {
	TIMER_MODES_t modes;
	TIMER_PRESCALER_t prescaler;

}ST_TIMER_config_t;

#endif /* MCAL_TIMER0_TIMER_TYPES_H_ */
