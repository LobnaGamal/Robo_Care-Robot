/*
 * main.c
 *
 *  Created on: Apr 27, 2020
 *      Author: Lobna Gamal
 */

extern void Task_Test(void);


int main(void)
{


	Task_Test();


	while (1)
		{
			;
		}

	return 0;
}





